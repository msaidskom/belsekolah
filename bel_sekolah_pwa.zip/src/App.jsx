import React, { useEffect, useState, useRef } from 'react'
import { get, set } from 'idb-keyval'

const DEFAULT_SCHEDULE = [
  { id: 1, name: 'Berdoa', hour: 7, minute: 0, enabled: true },
  { id: 2, name: 'Jam 1', hour: 7, minute: 15, enabled: true },
  { id: 3, name: 'Jam 2', hour: 8, minute: 0, enabled: true },
  { id: 4, name: 'Jam 3', hour: 8, minute: 45, enabled: true },
  { id: 5, name: 'Istirahat', hour: 9, minute: 30, enabled: true },
  { id: 6, name: 'Jam 4', hour: 9, minute: 45, enabled: true },
  { id: 7, name: 'Jam 5', hour: 10, minute: 30, enabled: true },
  { id: 8, name: 'Jam 6', hour: 11, minute: 15, enabled: true },
  { id: 9, name: 'Ishoma', hour: 12, minute: 0, enabled: true },
  { id: 10, name: 'Jam 7', hour: 13, minute: 0, enabled: true },
  { id: 11, name: 'Jam 8', hour: 13, minute: 45, enabled: true },
  { id: 12, name: 'Istirahat 3', hour: 14, minute: 30, enabled: true },
  { id: 13, name: 'Jam 9', hour: 14, minute: 45, enabled: true },
  { id: 14, name: 'Jam 10', hour: 15, minute: 30, enabled: true },
  { id: 15, name: 'Jam 11', hour: 16, minute: 15, enabled: true },
  { id: 16, name: 'Pulang', hour: 16, minute: 55, enabled: true }
]

function formatHM(h,m){return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`}

export default function App(){
  const [schedule, setSchedule] = useState(DEFAULT_SCHEDULE)
  const [soundName, setSoundName] = useState('Default bel bawaan')
  const audioRef = useRef(null)

  useEffect(()=>{ // load from storage (idb)
    (async()=>{
      const s = await get('schedule')
      const sn = await get('soundName')
      const soundBlob = await get('soundBlob')
      if(s) setSchedule(s)
      if(sn) setSoundName(sn)
      if(soundBlob){
        const url = URL.createObjectURL(soundBlob)
        audioRef.current = new Audio(url)
      } else {
        // simple short beep fallback (silent placeholder)
        audioRef.current = new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAgAAAAQAAACAA...')
      }
    })()
  },[])

  useEffect(()=>{ // save schedule when changed
    set('schedule', schedule)
  },[schedule])

  // timer: check every 15s for due bells
  useEffect(()=>{
    const tick = async ()=>{
      const now = new Date()
      const hh = now.getHours(), mm = now.getMinutes()
      for(const p of schedule){
        if(!p.enabled) continue
        if(p.hour===hh && p.minute===mm){
          const key = `${p.id}_${now.getDate()}_${hh}_${mm}`
          if(localStorage.getItem('lastPlayed')===key) return
          playBell(p)
          localStorage.setItem('lastPlayed', key)
        }
      }
    }
    tick()
    const id = setInterval(tick,15000)
    return ()=>clearInterval(id)
  },[schedule])

  async function playBell(period){
    try{
      if(!audioRef.current) return
      await audioRef.current.play()
    }catch(e){
      console.warn('play failed',e)
    }
    if(Notification.permission==='granted'){
      new Notification('Bel Sekolah', { body: `${period.name} — ${formatHM(period.hour,period.minute)}` })
    }
  }

  async function pickSound(ev){
    const file = ev.target.files[0]
    if(!file) return
    const blob = file.slice(0,file.size,file.type)
    await set('soundBlob', blob)
    await set('soundName', file.name)
    setSoundName(file.name)
    const url = URL.createObjectURL(blob)
    audioRef.current = new Audio(url)
  }

  function toggleEnabled(id){
    const s = schedule.map(p=> p.id===id?{...p, enabled:!p.enabled}:p)
    setSchedule(s)
  }

  function manualPlay(){
    const fake = {id:999,name:'Manual',hour:new Date().getHours(), minute:new Date().getMinutes()}
    playBell(fake)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white p-6">
      <div className="max-w-3xl mx-auto">
        <header className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Bel Sekolah</h1>
          <div>
            <button onClick={()=>Notification.requestPermission()} className="px-3 py-1 bg-indigo-600 text-white rounded">Izinkan Notif</button>
          </div>
        </header>

        <section className="mt-6 bg-white p-4 rounded-lg shadow">
          <h2 className="font-semibold">Suara Bel</h2>
          <div className="mt-3 flex items-center gap-3">
            <label className="cursor-pointer bg-indigo-50 px-3 py-2 rounded">
              Pilih MP3
              <input accept="audio/*" onChange={pickSound} type="file" className="hidden" />
            </label>
            <div className="text-sm text-slate-600">{soundName}</div>
            <button onClick={manualPlay} className="ml-auto bg-green-500 text-white px-3 py-2 rounded">Manual Bel</button>
          </div>
        </section>

        <section className="mt-6">
          <h2 className="text-lg font-semibold">Jadwal</h2>
          <div className="mt-3 space-y-2">
            {schedule.map(p=> (
              <div key={p.id} className="flex items-center bg-white p-3 rounded shadow-sm">
                <div className="w-40">
                  <div className="font-medium">{p.name}</div>
                  <div className="text-sm text-slate-500">{formatHM(p.hour,p.minute)}</div>
                </div>
                <div className="flex-1"></div>
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={p.enabled} onChange={()=>toggleEnabled(p.id)} />
                  <span className="text-sm">Aktif</span>
                </label>
              </div>
            ))}
          </div>
        </section>

        <footer className="mt-8 text-sm text-slate-500 text-center">Pasang sebagai PWA (Add to home screen) agar bisa berjalan di latar lebih baik pada Android.</footer>
      </div>
    </div>
  )
}
